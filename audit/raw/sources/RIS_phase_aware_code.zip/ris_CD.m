% ris_CD.m
% Coordinate Descent phase optimization for RIS.
%
% At each iteration, updates one element at a time using the closed-form
% optimal phase (all other elements fixed). O(K * N^2) per sample.
%
% Usage:
%   [Theta, h_eff, rmse_deg, t_ms] = ris_CD(F, G, h_d, maxIter)
%
% Inputs:
%   F, G     : [numSamples x N]  BS-RIS and RIS-UE channels
%   h_d      : [numSamples x 1]  direct channel
%   maxIter  : number of CD iterations (paper uses K=5)
%
% Outputs:
%   Theta    : [numSamples x N]  optimized phase configuration (complex exp)
%   h_eff    : [numSamples x 1]  effective channel
%   rmse_deg : phase-aware RMSE vs closed-form optimum [degrees]
%   t_ms     : average inference time per sample [ms]

function [Theta_all, h_eff_est, rmse_deg, t_ms] = ris_CD(F, G, h_d, maxIter)

if nargin < 4 || isempty(maxIter)
    maxIter = 5;
end

[numSamples, N] = size(F);
Theta_all = ones(numSamples, N);
h_eff_est = zeros(numSamples, 1);
t_total   = 0;

for s = 1:numSamples
    Fs = F(s,:);  Gs = G(s,:);  hd = h_d(s);
    Th = ones(1, N);

    t0 = tic;
    for it = 1:maxIter
        for n = 1:N
            mask = true(1, N);  mask(n) = false;
            Hm = hd + sum(Gs(mask) .* (Th(mask) .* Fs(mask)));
            th_opt = angle(Hm) - angle(Gs(n) * Fs(n));
            th_opt = mod(th_opt + pi, 2*pi) - pi;
            Th(n)  = exp(1j * th_opt);
        end
    end
    t_total = t_total + toc(t0);

    Theta_all(s,:) = Th;
    h_eff_est(s)   = hd + sum(Gs .* (Th .* Fs));
end

t_ms = (t_total / numSamples) * 1e3;

% phase-aware RMSE vs closed-form optimum
THETA_ref  = -angle(G) - angle(F);
THETA_pred = angle(Theta_all);
err        = angle(exp(1j * (THETA_pred - THETA_ref)));
rmse_deg   = sqrt(mean(err(:).^2)) * (180/pi);

fprintf('CD (K=%d)  |  RMSE = %.2f deg  |  %.3f ms/sample\n', maxIter, rmse_deg, t_ms);
end
