% Figure1_scalability.m
% Reproduces Figure 1: inference latency vs. N for CNN-LSTM, CD and
% CNN-Transformer, on a logarithmic axis with the 6G URLLC 1 ms limit.
%
% Data: scalability_analysis.m (measured values from the paper).

clear; close all; clc;

N_vals = [32, 64, 128, 256];

time_cnn = [0.08, 0.16, 0.32, 0.64];    % O(N)
time_cd  = [0.15, 3.04, 12.20, 73.00];  % CD (K=5), O(K*N^2)
time_trf = [1.10, 4.40, 17.60, 48.60];  % CNN-Transformer, O(N^2)

URLLC_ms = 1.0;

clr_cnn = [0.00, 0.45, 0.74];
clr_cd  = [0.93, 0.69, 0.13];
clr_tr  = [0.85, 0.33, 0.10];

fig = figure('Color', 'w', 'Position', [100 100 720 520]);
ax  = axes(fig);

h1 = semilogy(ax, N_vals, time_cnn, '-o', 'LineWidth', 2.5, 'MarkerSize', 9, ...
    'Color', clr_cnn, 'MarkerFaceColor', clr_cnn, 'DisplayName', 'CNN-LSTM  [O(N)]');
hold(ax, 'on');
h2 = semilogy(ax, N_vals, time_cd, '-^', 'LineWidth', 2.5, 'MarkerSize', 9, ...
    'Color', clr_cd, 'MarkerFaceColor', clr_cd, 'DisplayName', 'Coordinate Descent (K=5)  [O(K \cdot N^{2})]');
h3 = semilogy(ax, N_vals, time_trf, '-s', 'LineWidth', 2.5, 'MarkerSize', 9, ...
    'Color', clr_tr, 'MarkerFaceColor', clr_tr, 'DisplayName', 'CNN-Transformer  [O(N^{2})]');
h4 = yline(ax, URLLC_ms, '--k', 'LineWidth', 2.2, 'DisplayName', '6G URLLC limit (1 ms)');

% URLLC-safe zone shading
fill(ax, [N_vals(1) N_vals(end) N_vals(end) N_vals(1)], ...
         [URLLC_ms URLLC_ms 0.03 0.03], ...
    [0.85 1.0 0.85], 'FaceAlpha', 0.18, 'EdgeColor', 'none', 'HandleVisibility', 'off');

for i = 1:length(N_vals)
    text(ax, N_vals(i)+6, time_cnn(i)*1.45, sprintf('%.2f ms', time_cnn(i)), ...
        'Color', clr_cnn, 'FontWeight', 'bold', 'FontSize', 8.5);
end

text(ax, 34, 0.40, '\leftarrow URLLC safe zone', 'Color', [0.05 0.45 0.05], ...
    'FontSize', 9.5, 'FontAngle', 'italic');
text(ax, 34, 7.0, '\uparrow Exceeds URLLC limit', 'Color', [0.75 0.10 0.10], ...
    'FontSize', 9.5, 'FontAngle', 'italic');

xlim(ax, [20, 290]);  ylim(ax, [0.05, 150]);
xticks(ax, N_vals);  xticklabels(ax, {'32', '64', '128', '256'});
xlabel(ax, 'Number of RIS elements (N)', 'FontSize', 13, 'FontWeight', 'bold');
ylabel(ax, 'Inference latency [ms] (log scale)', 'FontSize', 13, 'FontWeight', 'bold');
title(ax, 'Scalability analysis: inference latency vs. N', 'FontSize', 13, 'FontWeight', 'bold');
grid(ax, 'on');  box(ax, 'on');
legend(ax, [h1 h2 h3 h4], 'Location', 'northwest', 'FontSize', 10.5);

exportgraphics(fig, 'Figure1_scalability.eps', 'ContentType', 'vector');
exportgraphics(fig, 'Figure1_scalability.png', 'Resolution', 300);
fprintf('Saved: Figure1_scalability.eps / .png\n');
