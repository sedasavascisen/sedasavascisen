# Phase-Aware CNN-LSTM for RIS Phase Optimization

Code for the paper:

> **Overcoming the Phase Discontinuity Problem in RIS Optimization: A Robust and Scalable Phase-Aware Deep Regression Framework via Hybrid CNN-LSTM Architecture**
> Seda Savaşçı Şen, Ali Çalhan, Murtaza Cicioğlu, Oğuzhan Demiryürek
> *Advanced Intelligent Systems*, 2026. DOI: 10.1002/aisy.70460

---

## Overview

RIS phase optimization requires predicting a phase angle per element. Training a
neural network to regress angles directly hits the ±π discontinuity: two almost
identical phases near +π and −π produce a huge loss, which misleads the optimizer.

We fix this by predicting `[sin(θ), cos(θ)]` instead of `θ` and recovering the
angle via `atan2`. The mapping is smooth everywhere on the unit circle and the
gradient stays bounded regardless of the phase value (Propositions 1 and 2).

The network is a hybrid CNN-LSTM: 1D convolutions extract local element
correlations, and a stacked LSTM captures longer-range inter-element dependencies
arising from the row-major serialization of the panel.

**Main result:** phase-aware RMSE of **2.77°** on a 32-element RIS at **0.08 ms**
inference per sample on CPU — inside the 6G URLLC 1 ms budget.

---

## Repository structure

```
├── RIS_dataset_large_2D.m          # dataset generation (run first)
├── theta_NN_multioutput.m          # CNN-LSTM training and evaluation (MATLAB)
├── train_cnn_lstm.py               # same model in PyTorch
│
├── ris_CD.m                        # Coordinate Descent baseline
├── ris_AO.m                        # Alternating Optimization baseline
├── ris_WMMSE.m                     # Weighted MMSE baseline
├── ris_SPA.m                       # Successive Phase Alignment baseline
├── ris_PSO.m                       # Particle Swarm Optimization baseline
├── ris_PGD.m                       # Projected Gradient Descent baseline
│
├── transformer_baseline.m          # CNN-Transformer and FC-DNN comparison (Table 6)
├── theoretical_gradient_analysis.m # Propositions 1 & 2 verification
├── scalability_analysis.m          # N = {32, 64, 128, 256} latency and RMSE fit
├── baseline_fairness_K_analysis.m  # CD with K = {5, 20, 50} iterations
│
├── Figure1_scalability.m           # latency vs N (log scale)
├── Figure2_fairness.m              # CD RMSE and latency vs K
├── Figure7_comparison.m            # bar chart, all 11 methods
└── plot_results.m                  # test-set visualizations (incl. error CDF)
```

---

## Requirements

**MATLAB** R2022b or later with Deep Learning Toolbox.
GPU recommended; set `ExecutionEnvironment='cpu'` if unavailable.
(Paper results: MATLAB R2024a, Intel Core i7-9700K, RTX 2080 Ti.)

**Python** (optional path): Python ≥ 3.9, PyTorch ≥ 1.12.
```
pip install torch scipy numpy matplotlib
```

---

## Quickstart

### 1. Generate the dataset

```matlab
run('RIS_dataset_large_2D.m')
```

Creates `RIS_dataset_large_2D.mat` with 40,000 samples: BS→RIS channel `F`,
RIS→UE channel `G`, direct channel `h_d`, and optimal phase labels `THETA`.
About 10 minutes on a standard laptop.

### 2. Train the CNN-LSTM

```matlab
run('theta_NN_multioutput.m')
```

or, in Python:

```bash
python train_cnn_lstm.py --data_path RIS_dataset_N32.mat --N 32
```

Expected output for N = 32:

```
Phase-aware RMSE : 2.77 deg
Avg inference    : 0.08 ms/sample
SR@5 deg         : 95%
```

### 3. Run the baselines

```matlab
[Theta, h_eff, rmse, t]   = ris_CD(F, G, h_d, 5);    % Coordinate Descent
[Theta, h_eff, MSE, RMSE] = ris_AO(F, G, h_d, 5);    % Alternating Optimization
[Theta, h_eff, MSE, RMSE] = ris_PGD(F, G, h_d);      % Projected Gradient Descent
[Theta, h_eff, MSE, RMSE] = ris_WMMSE(F, G, h_d, 10);
[Theta, h_eff, MSE, RMSE] = ris_PSO(F, G, h_d);
[Theta, h_eff, MSE, RMSE] = ris_SPA(F, G, h_d);
```

### 4. Reproduce the figures

```matlab
run('Figure7_comparison.m')
run('Figure2_fairness.m')
run('Figure1_scalability.m')
run('theoretical_gradient_analysis.m')
```

---

## Dataset

3 GHz indoor scenario, 40 m × 20 m × 6 m room:

- 8 × 4 RIS panel (N = 32, λ/2 = 0.05 m spacing)
- 6 random scatterers per sample, scattering gain 0.15
- Rayleigh fading on all links, path loss exponent 2
- TX and RX positions drawn uniformly over the room
- Transmit power 1 W, noise power 10⁻³ W

Optimal phase labels use the closed-form single-user solution
θ\* = −∠G − ∠F (Eq. 8), wrapped to [−π, π].

For the scalability experiments (N = 64, 128, 256), change `M` and `K` in
`RIS_dataset_large_2D.m` and retrain from scratch — no weight transfer is used.

---

## Results (Table 6, N = 32)

| Method | RMSE [°] | SR@5° | Latency [ms] | Complexity |
|---|---|---|---|---|
| **CNN-LSTM (proposed)** | **2.77** | **95%** | **0.08** | O(N) |
| CD | 3.50 | 78% | 0.15 | O(KN²) |
| AO | 3.50 | 78% | 0.18 | O(KN²) |
| PGD | 4.00 | 71% | 0.50 | O(IN) |
| WMMSE | 4.00 | 71% | 0.20 | O(KN²) |
| PSO | 4.50 | 64% | 15.0 | O(PIN) |
| SPA | 5.00 | 57% | 0.05 | O(N) |
| FC-DNN (direct θ) | 3.95 | 82% | 0.04 | O(N) |
| FC-DNN (sin/cos) | 3.41 | 89% | 0.04 | O(N) |
| CNN-Transformer | 2.91 | 93% | 0.11 | O(N²) |
| GCN (spatial) | 3.12 | 91% | 0.09 | O(N) |

Scalability (Table 8): 0.08 / 0.16 / 0.32 / 0.64 ms for N = 32 / 64 / 128 / 256 —
the only method below 1 ms at every array size.

---

## Citation

```bibtex
@article{savascisen2026ris,
  title   = {Overcoming the Phase Discontinuity Problem in RIS Optimization:
             A Robust and Scalable Phase-Aware Deep Regression Framework
             via Hybrid CNN-LSTM Architecture},
  author  = {Sava{\c{s}}{\c{c}}{\i} {\c{S}}en, Seda and {\c{C}}alhan, Ali and
             Cicio{\u{g}}lu, Murtaza and Demiry{\"u}rek, O{\u{g}}uzhan},
  journal = {Advanced Intelligent Systems},
  year    = {2026},
  doi     = {10.1002/aisy.70460}
}
```

---

## Contact

Seda Savaşçı Şen — sedasavascisen@duzce.edu.tr
