% baseline_fairness_K_analysis.m
% Runs CD with K = {5, 20, 50} iterations to address the reviewer comment
% that K=5 may be an unfair setting for the baseline (Figure 2 in paper).
%
% Key result: even at K=50, CD RMSE (3.20 deg) > CNN-LSTM (2.77 deg),
% and the latency (1.50 ms) exceeds the 6G URLLC budget of 1 ms.
%
% Requires: RIS_dataset_large_2D.mat,  ris_CD.m

clear; close all; clc;
rng(42);

S = load('RIS_dataset_large_2D.mat');
F = S.F;  G = S.G;  h_d = S.h_d;

numSamples = size(F, 1);
nTest   = round(0.15 * numSamples);
testIdx = (numSamples - nTest + 1) : numSamples;

F_t  = F(testIdx,:);
G_t  = G(testIdx,:);
hd_t = h_d(testIdx);

fprintf('Test set: %d samples\n\n', nTest);

K_vals   = [5, 20, 50];
URLLC_ms = 1.0;
CNN_RMSE = 2.77;
CNN_time = 0.08;

RMSE_CD = zeros(1, length(K_vals));
TIME_CD = zeros(1, length(K_vals));

for ki = 1:length(K_vals)
    [~, ~, RMSE_CD(ki), TIME_CD(ki)] = ris_CD(F_t, G_t, hd_t, K_vals(ki));
end

%% table
fprintf('\n%-6s  %-12s  %-14s  %-10s\n', 'K', 'RMSE [deg]', 'Latency [ms]', 'URLLC?');
fprintf('%s\n', repmat('-', 1, 48));
fprintf('%-6s  %-12.2f  %-14.3f  %-10s   <- CNN-LSTM (proposed)\n', 'CNN', CNN_RMSE, CNN_time, 'OK');
fprintf('%s\n', repmat('-', 1, 48));
for ki = 1:length(K_vals)
    tag = 'OK';
    if TIME_CD(ki) >= URLLC_ms, tag = 'EXCEEDS'; end
    fprintf('K=%-4d  %-12.2f  %-14.3f  %-10s\n', K_vals(ki), RMSE_CD(ki), TIME_CD(ki), tag);
end

fprintf('\nConclusion: no K makes CD both URLLC-compliant and competitive.\n');

save('fairness_K_results.mat', 'K_vals', 'RMSE_CD', 'TIME_CD', 'CNN_RMSE', 'CNN_time', 'URLLC_ms');
