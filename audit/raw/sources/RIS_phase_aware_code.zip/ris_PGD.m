% ris_PGD.m
% Projected Gradient Descent for RIS phase optimization.
% Each gradient step is projected back to the unit circle via angle().
%
% Usage:
%   [Theta, h_eff, MSE, RMSE] = ris_PGD(F, G, h_d, stepSize, maxIter)
%
% Defaults: stepSize=0.2, maxIter=50 (paper setting)

function [Theta_all, h_eff_all, MSE, RMSE] = ris_PGD(F, G, h_d, stepSize, maxIter)

if nargin < 4 || isempty(stepSize), stepSize = 0.2; end
if nargin < 5 || isempty(maxIter),  maxIter  = 50;  end

[numSamples, N] = size(F);
Theta_all = ones(numSamples, N);
h_eff_all = zeros(numSamples, 1);

for s = 1:numSamples
    Fs = F(s,:);  Gs = G(s,:);  hd = h_d(s);
    a  = Gs .* Fs;
    z  = ones(1, N);

    for it = 1:maxIter
        h    = hd + sum(a .* z);
        z    = z + stepSize * conj(h) * a;
        z    = exp(1j * angle(z));   % project to unit circle
    end

    Theta_all(s,:) = z;
    h_eff_all(s)   = hd + sum(a .* z);
end

h_base = h_d + sum(G .* F, 2);
MSE    = mean(abs(h_base - h_eff_all).^2);
RMSE   = sqrt(MSE);

fprintf('PGD (step=%.2f, K=%d)  MSE = %.6e,  RMSE = %.6e\n', stepSize, maxIter, MSE, RMSE);
end
