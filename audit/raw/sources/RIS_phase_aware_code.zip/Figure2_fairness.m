% Figure2_fairness.m
% Reproduces Figure 2: CD RMSE and inference latency vs. iteration count K,
% compared against CNN-LSTM and the 6G URLLC 1 ms limit.
%
% Values come from baseline_fairness_K_analysis.m.

clear; close all; clc;

K_vals   = [5, 20, 50];
RMSE_CD  = [3.50, 3.49, 3.20];   % deg
TIME_CD  = [0.15, 0.60, 1.50];   % ms

CNN_RMSE = 2.77;
CNN_time = 0.08;
URLLC_ms = 1.0;

fig = figure('Color', 'w', 'Position', [100 100 820 540]);
ax1 = axes(fig);

yyaxis(ax1, 'left');
h1 = plot(ax1, K_vals, RMSE_CD, '-sb', 'LineWidth', 2.5, 'MarkerSize', 10, ...
    'MarkerFaceColor', [0.00 0.45 0.74], 'DisplayName', 'CD (K) - Phase-Aware RMSE');
hold(ax1, 'on');
h2 = yline(ax1, CNN_RMSE, '--b', 'LineWidth', 2, ...
    'DisplayName', sprintf('CNN-LSTM RMSE (%.2f deg)', CNN_RMSE));
ylim(ax1, [2.40, 4.20]);
ylabel(ax1, 'Phase-Aware RMSE [deg]', 'FontSize', 13, 'FontWeight', 'bold');
ax1.YColor = [0.00 0.45 0.74];

yyaxis(ax1, 'right');
h3 = plot(ax1, K_vals, TIME_CD, '-or', 'LineWidth', 2.5, 'MarkerSize', 10, ...
    'MarkerFaceColor', [0.85 0.10 0.10], 'DisplayName', 'CD (K) - Inference Latency');
h4 = yline(ax1, URLLC_ms, '--k', 'LineWidth', 2, 'DisplayName', '6G URLLC limit (1 ms)');
h5 = yline(ax1, CNN_time, ':', 'Color', [0.85 0.33 0.10], 'LineWidth', 2.2, ...
    'DisplayName', sprintf('CNN-LSTM latency (%.2f ms)', CNN_time));
ylim(ax1, [-0.5, 14]);
ylabel(ax1, 'Inference Latency [ms]', 'FontSize', 13, 'FontWeight', 'bold');
ax1.YColor = [0.85 0.10 0.10];

fill(ax1, [20 50 50 20], [URLLC_ms URLLC_ms 14 14], ...
    [1.0 0.88 0.88], 'FaceAlpha', 0.25, 'EdgeColor', 'none', 'HandleVisibility', 'off');
text(ax1, 30, 5.5, 'K \geq 20: URLLC Exceeded', 'Color', [0.75 0.10 0.10], ...
    'FontSize', 10, 'FontWeight', 'bold', 'FontAngle', 'italic');

yyaxis(ax1, 'right');
for i = 1:length(K_vals)
    flag = '';  if TIME_CD(i) >= URLLC_ms, flag = '  x'; end
    text(ax1, K_vals(i)+0.8, TIME_CD(i)+0.28, [sprintf('%.2f ms', TIME_CD(i)) flag], ...
        'Color', [0.85 0.10 0.10], 'FontWeight', 'bold', 'FontSize', 9);
end
yyaxis(ax1, 'left');
for i = 1:length(K_vals)
    text(ax1, K_vals(i)+0.8, RMSE_CD(i)+0.025, sprintf('%.2f deg', RMSE_CD(i)), ...
        'Color', [0.00 0.45 0.74], 'FontWeight', 'bold', 'FontSize', 9);
end

xlabel(ax1, 'Iteration Count (K) for Baseline Algorithms', 'FontSize', 13, 'FontWeight', 'bold');
title(ax1, 'Baseline Fairness: CD RMSE and Latency vs. Iteration Count K', ...
      'FontSize', 13, 'FontWeight', 'bold');
xlim(ax1, [3, 52]);  xticks(ax1, K_vals);  xticklabels(ax1, {'K = 5', 'K = 20', 'K = 50'});
xline(ax1, 20, '-.k', 'LineWidth', 1.5, 'HandleVisibility', 'off');
grid(ax1, 'on');  box(ax1, 'on');
legend(ax1, [h1 h2 h3 h4 h5], 'Location', 'northeast', 'FontSize', 10);

exportgraphics(fig, 'Figure2_fairness.eps', 'ContentType', 'vector');
exportgraphics(fig, 'Figure2_fairness.png', 'Resolution', 300);
fprintf('Saved: Figure2_fairness.eps / .png\n');
