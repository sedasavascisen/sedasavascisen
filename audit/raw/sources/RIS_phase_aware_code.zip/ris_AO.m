% ris_AO.m
% Alternating Optimization for RIS phase configuration.
%
% Same idea as CD but updates phases in a slightly different order;
% included as a separate baseline for fair comparison (Table 6).
%
% Usage:  [Theta, h_eff, MSE, RMSE] = ris_AO(F, G, h_d, maxIter)

function [Theta_all, h_eff_est, MSE, RMSE] = ris_AO(F, G, h_d, maxIter)

if nargin < 4
    maxIter = 1;
end

[numSamples, N] = size(F);
Theta_all = ones(numSamples, N);
h_eff_est = zeros(numSamples, 1);

for s = 1:numSamples
    Fs = F(s,:);  Gs = G(s,:);  hd = h_d(s);
    Th = ones(1, N);

    for it = 1:maxIter
        for n = 1:N
            mask = true(1, N);  mask(n) = false;
            H_mn = hd + sum(Gs(mask) .* (Th(mask) .* Fs(mask)));
            th_n = angle(H_mn) - angle(Gs(n) * Fs(n));
            th_n = mod(th_n + pi, 2*pi) - pi;
            Th(n) = exp(1j * th_n);
        end
    end

    Theta_all(s,:) = Th;
    h_eff_est(s)   = hd + sum(Gs .* (Th .* Fs));
end

h_true = h_d + sum(G .* F, 2);
MSE    = mean(abs(h_true - h_eff_est).^2);
RMSE   = sqrt(MSE);

fprintf('AO (K=%d)  MSE = %.6f,  RMSE = %.6f\n', maxIter, MSE, RMSE);
end
