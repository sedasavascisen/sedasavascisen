% ris_SPA.m
% Successive Phase Alignment for RIS.
% Greedy: aligns element n to the accumulated effective channel, in order.
%
% Usage:  [Theta, h_eff, MSE, RMSE] = ris_SPA(F, G, h_d)

function [Theta_all, h_eff_est, MSE, RMSE] = ris_SPA(F, G, h_d)

[numSamples, N] = size(F);
Theta_all = ones(numSamples, N);
h_eff_est = zeros(numSamples, 1);

for s = 1:numSamples
    Fs = F(s,:);  Gs = G(s,:);  hd = h_d(s);
    Th    = ones(1, N);
    H_acc = hd;

    for n = 1:N
        phi_n  = angle(H_acc) - angle(Gs(n) * Fs(n));
        phi_n  = mod(phi_n + pi, 2*pi) - pi;
        Th(n)  = exp(1j * phi_n);
        H_acc  = H_acc + Gs(n) * Fs(n) * Th(n);
    end

    Theta_all(s,:) = Th;
    h_eff_est(s)   = H_acc;
end

h_true = h_d + sum(G .* F, 2);
MSE    = mean(abs(h_true - h_eff_est).^2);
RMSE   = sqrt(MSE);

fprintf('SPA  MSE = %.6f,  RMSE = %.6f\n', MSE, RMSE);
end
