% Figure7_comparison.m
% Bar chart comparing phase-aware RMSE across all 11 methods (Table 6).
% Values match the published table; no re-training needed.
%
% Run theta_NN_multioutput.m, transformer_baseline.m and the baseline
% scripts first if you want to verify the numbers yourself.

clear; close all; clc;

% RMSE and std values (Table 6)
rmse = [2.77, 3.50, 3.50, 4.00, 4.00, 4.50, 5.00, 3.95, 3.41, 2.91, 3.12];
err  = [1.15, 1.42, 1.38, 1.68, 1.65, 1.88, 2.15, 1.71, 1.50, 1.22, 1.33];

labels    = {'CNN-LSTM', 'CD', 'AO', 'PGD', 'WMMSE', 'PSO', 'SPA', ...
             'FC-DNN', 'FC-DNN', 'CNN-Trans.', 'GCN'};
sublabels = {'(Proposed)', '', '', '', '', '', '', '(direct)', '(sin/cos)', '', '(spatial)'};

n = length(rmse);

c_proposed  = [0.12, 0.47, 0.71];
c_classical = [0.28 0.28 0.28; 0.38 0.38 0.38; 0.48 0.48 0.48; ...
               0.55 0.55 0.55; 0.65 0.65 0.65; 0.76 0.76 0.76];
c_dl        = [0.99 0.82 0.10; 0.95 0.58 0.08; 0.88 0.78 0.05; 0.78 0.42 0.03];

colors = [c_proposed; c_classical; c_dl];

fig = figure('Units', 'centimeters', 'Position', [2 2 22 11], 'Color', 'w');
ax  = axes('Parent', fig);
hold(ax, 'on');

for i = 1:n
    bar(ax, i, rmse(i), 0.62, 'FaceColor', colors(i,:), 'EdgeColor', 'k', 'LineWidth', 0.8);
    errorbar(ax, i, rmse(i), err(i), 'k', 'LineWidth', 0.9, 'CapSize', 4);

    y_lbl = rmse(i) + err(i) + 0.13;
    if i == 1
        text(ax, i, y_lbl, sprintf('\\bf%.2f deg', rmse(i)), ...
            'HorizontalAlignment', 'center', 'FontSize', 8.5, 'Color', c_proposed);
    else
        text(ax, i, y_lbl, sprintf('%.2f deg', rmse(i)), ...
            'HorizontalAlignment', 'center', 'FontSize', 7.5, 'Color', [0.15 0.15 0.15]);
    end
end

yline(ax, 2.77, '--', 'Color', [0.10 0.45 0.70], 'LineWidth', 1.3);
text(ax, 0.6, 2.77 + 0.18, '- CNN-LSTM: 2.77 deg', 'FontSize', 8, ...
    'Color', [0.10 0.45 0.70], 'FontWeight', 'bold');

xline(ax, 7.5, '--', 'Color', [0.40 0.40 0.40], 'LineWidth', 1.2);
text(ax, 8.0, 3.6, 'DL Baselines \rightarrow', 'FontSize', 8.5, ...
    'Color', [0.35 0.35 0.35], 'FontAngle', 'italic', 'FontWeight', 'bold');

set(ax, 'XTick', 1:n, 'XTickLabel', labels, 'XTickLabelRotation', 30, 'FontSize', 8.5);
for i = 1:n
    if ~isempty(sublabels{i})
        text(ax, i, -0.70, sublabels{i}, 'HorizontalAlignment', 'center', ...
            'FontSize', 7.5, 'Color', [0.30 0.30 0.30]);
    end
end

xlabel(ax, 'Method', 'FontSize', 10, 'FontWeight', 'bold');
ylabel(ax, 'Phase-Aware RMSE [deg]', 'FontSize', 10, 'FontWeight', 'bold');
title(ax, 'Performance Comparison of RIS Phase Optimization Methods', ...
    'FontSize', 10, 'FontWeight', 'bold');

hp = patch(NaN, NaN, c_proposed,      'EdgeColor', 'k');
hc = patch(NaN, NaN, c_classical(2,:),'EdgeColor', 'k');
hd = patch(NaN, NaN, c_dl(1,:),       'EdgeColor', 'k');
legend(ax, [hp, hc, hd], {'CNN-LSTM (Proposed)', 'Classical Baselines', 'DL Baselines'}, ...
    'Location', 'northeast', 'FontSize', 8.5);

set(ax, 'YLim', [0 7.0], 'YTick', 0:1:6, 'XLim', [0.3 n+0.7], ...
    'Box', 'on', 'YGrid', 'on', 'GridAlpha', 0.22, 'TickDir', 'out');

exportgraphics(fig, 'Figure7_comparison.eps', 'ContentType', 'vector');
exportgraphics(fig, 'Figure7_comparison.png', 'Resolution', 300);
fprintf('Saved: Figure7_comparison.eps / .png\n');
