% ris_WMMSE.m
% Weighted MMSE-based phase optimization for RIS.
% Gradient step on the effective channel magnitude (simplified single-user case).
%
% Usage:  [Theta, h_eff, MSE, RMSE] = ris_WMMSE(F, G, h_d, maxIter)

function [Theta_all, h_eff_est, MSE, RMSE] = ris_WMMSE(F, G, h_d, maxIter)

if nargin < 4
    maxIter = 1;
end

[numSamples, N] = size(F);
Theta_all = ones(numSamples, N);
h_eff_est = zeros(numSamples, 1);

step = 0.1;

for s = 1:numSamples
    Fs = F(s,:);  Gs = G(s,:);  hd = h_d(s);
    Th = ones(1, N);

    for it = 1:maxIter
        H_eff = hd + sum(Gs .* (Th .* Fs));
        for n = 1:N
            grad   = -2 * imag(conj(Gs(n) * Fs(n)) * H_eff);
            th_n   = angle(Th(n)) - step * grad;
            th_n   = mod(th_n + pi, 2*pi) - pi;
            Th(n)  = exp(1j * th_n);
        end
    end

    Theta_all(s,:) = Th;
    h_eff_est(s)   = hd + sum(Gs .* (Th .* Fs));
end

h_true = h_d + sum(G .* F, 2);
MSE    = mean(abs(h_true - h_eff_est).^2);
RMSE   = sqrt(MSE);

fprintf('WMMSE (K=%d)  MSE = %.6f,  RMSE = %.6f\n', maxIter, MSE, RMSE);
end
