% ris_PSO.m
% Particle Swarm Optimization for RIS phase configuration.
%
% Usage:
%   [Theta, h_eff, MSE, RMSE] = ris_PSO(F, G, h_d)
%   [Theta, h_eff, MSE, RMSE] = ris_PSO(F, G, h_d, 20, 30, 0.7, 1.5, 1.5)
%
% Defaults: numParticles=20, maxIter=30, w=0.7, c1=1.5, c2=1.5

function [Theta_all, h_eff_all, MSE, RMSE] = ris_PSO(F, G, h_d, numParticles, maxIter, w, c1, c2)

if nargin < 4 || isempty(numParticles), numParticles = 20; end
if nargin < 5 || isempty(maxIter),      maxIter      = 30; end
if nargin < 6 || isempty(w),            w            = 0.7; end
if nargin < 7 || isempty(c1),           c1           = 1.5; end
if nargin < 8 || isempty(c2),           c2           = 1.5; end

[numSamples, N] = size(F);
Theta_all = ones(numSamples, N);
h_eff_all = zeros(numSamples, 1);

for s = 1:numSamples
    Fs = F(s,:);  Gs = G(s,:);  hd = h_d(s);
    a  = Fs .* Gs;

    phi = 2*pi * rand(numParticles, N);
    vel = zeros(numParticles, N);

    z     = exp(1j * phi);
    h_eff = hd + sum(a .* z, 2);
    fit   = abs(h_eff).^2;

    pbest_phi = phi;
    pbest_fit = fit;
    [gbest_fit, gi] = max(fit);
    gbest_phi = phi(gi, :);

    for t = 1:maxIter
        r1  = rand(numParticles, N);
        r2  = rand(numParticles, N);
        vel = w*vel + c1*r1.*(pbest_phi - phi) + c2*r2.*(gbest_phi - phi);
        phi = angle(exp(1j * (phi + vel)));

        z     = exp(1j * phi);
        h_eff = hd + sum(a .* z, 2);
        fit   = abs(h_eff).^2;

        better = fit > pbest_fit;
        pbest_phi(better,:) = phi(better,:);
        pbest_fit(better)   = fit(better);

        [best_t, bi] = max(fit);
        if best_t > gbest_fit
            gbest_fit = best_t;
            gbest_phi = phi(bi, :);
        end
    end

    Theta_all(s,:) = exp(1j * gbest_phi);
    h_eff_all(s)   = hd + sum(a .* Theta_all(s,:));

    if mod(s, 5000) == 0
        fprintf('PSO: %d/%d\n', s, numSamples);
    end
end

h_base = h_d + sum(G .* F, 2);
MSE    = mean(abs(h_base - h_eff_all).^2);
RMSE   = sqrt(MSE);

fprintf('PSO  MSE = %.6e,  RMSE = %.6e\n', MSE, RMSE);
end
